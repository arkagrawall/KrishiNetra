import { motion } from "motion/react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import {
  CheckCircle,
  Clock,
  FileText,
  MessageSquare,
  Eye,
  IndianRupee,
  TrendingUp,
} from "lucide-react";

const claims = [
  {
    id: "CLM2024-001",
    crop: "Wheat - Field A",
    event: "Frost Damage",
    status: "completed",
    amount: 45000,
    date: "Jan 15, 2024",
    progress: 100,
    hasProof: true,
  },
  {
    id: "CLM2024-002",
    crop: "Cotton - Field B",
    event: "Pest Infestation",
    status: "in-progress",
    amount: 32000,
    date: "Feb 20, 2024",
    progress: 65,
    hasProof: true,
  },
  {
    id: "CLM2024-003",
    crop: "Rice - Field C",
    event: "Flood Damage",
    status: "verified",
    amount: 58000,
    date: "Mar 5, 2024",
    progress: 30,
    hasProof: true,
  },
];

const statusConfig = {
  verified: {
    color: "bg-blue-500",
    text: "Verified",
    icon: CheckCircle,
  },
  "in-progress": {
    color: "bg-yellow-500",
    text: "Payout in Progress",
    icon: Clock,
  },
  completed: {
    color: "bg-green-500",
    text: "Completed",
    icon: CheckCircle,
  },
};

export function Claims() {
  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white border-b border-gray-200 p-4 sticky top-0 z-10"
      >
        <h1 className="text-foreground">My Claims</h1>
        <p className="text-sm text-muted-foreground">{claims.length} total claims</p>
      </motion.div>

      {/* Summary Cards */}
      <div className="p-4">
        <div className="grid grid-cols-2 gap-3 mb-6">
          {[
            {
              label: "Total Received",
              amount: 45000,
              color: "green",
              icon: CheckCircle,
            },
            {
              label: "Pending",
              amount: 90000,
              color: "blue",
              icon: Clock,
            },
          ].map((summary, index) => (
            <motion.div
              key={summary.label}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.1 + index * 0.1, type: "spring" }}
              whileHover={{ scale: 1.05, y: -5 }}
            >
              <Card
                className={`p-4 bg-${summary.color}-50 border-${summary.color}-200 relative overflow-hidden`}
              >
                {/* Background decoration */}
                <motion.div
                  className={`absolute top-0 right-0 w-20 h-20 bg-${summary.color}-200/30 rounded-full blur-2xl`}
                  animate={{
                    scale: [1, 1.2, 1],
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }}
                />

                <div className="relative z-10">
                  <div className="flex items-center gap-2 mb-2">
                    <summary.icon className={`w-4 h-4 text-${summary.color}-700`} />
                    <p className={`text-sm text-${summary.color}-700`}>
                      {summary.label}
                    </p>
                  </div>
                  <div className="flex items-center gap-1">
                    <IndianRupee className={`w-5 h-5 text-${summary.color}-700`} />
                    <motion.span
                      className={`text-xl text-${summary.color}-700`}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 0.2 + index * 0.1 }}
                    >
                      {summary.amount.toLocaleString()}
                    </motion.span>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Claims List */}
        <div className="space-y-4">
          {claims.map((claim, index) => {
            const config = statusConfig[claim.status];
            const StatusIcon = config.icon;

            return (
              <motion.div
                key={claim.id}
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{
                  delay: 0.2 + index * 0.1,
                  type: "spring",
                  stiffness: 100,
                }}
                whileHover={{ x: 5, scale: 1.02 }}
              >
                <Card className="overflow-hidden">
                  <div className="p-4">
                    {/* Header */}
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="text-foreground">{claim.crop}</h3>
                          <motion.div
                            initial={{ scale: 0 }}
                            animate={{ scale: 1 }}
                            transition={{ delay: 0.3 + index * 0.1, type: "spring" }}
                          >
                            <Badge
                              variant={
                                claim.status === "completed"
                                  ? "default"
                                  : claim.status === "in-progress"
                                  ? "secondary"
                                  : "outline"
                              }
                              className="text-xs"
                            >
                              <StatusIcon className="w-3 h-3 mr-1" />
                              {config.text}
                            </Badge>
                          </motion.div>
                        </div>
                        <p className="text-sm text-muted-foreground mb-1">
                          {claim.event}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Claim ID: {claim.id}
                        </p>
                      </div>
                    </div>

                    <div className="space-y-3">
                      {/* Amount */}
                      <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.4 + index * 0.1 }}
                        className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                      >
                        <span className="text-sm text-muted-foreground">
                          Payout Amount
                        </span>
                        <div className="flex items-center gap-1">
                          <IndianRupee className="w-4 h-4" />
                          <span className="text-foreground">
                            {claim.amount.toLocaleString()}
                          </span>
                        </div>
                      </motion.div>

                      {/* Progress */}
                      {claim.status !== "completed" && (
                        <motion.div
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: 0.5 + index * 0.1 }}
                        >
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-sm text-muted-foreground">
                              Processing Status
                            </span>
                            <motion.span
                              className="text-sm"
                              animate={{
                                scale: [1, 1.1, 1],
                              }}
                              transition={{
                                duration: 2,
                                repeat: Infinity,
                              }}
                            >
                              {claim.progress}%
                            </motion.span>
                          </div>
                          <Progress value={claim.progress} className="h-2" />
                        </motion.div>
                      )}

                      {/* Date */}
                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: 0.6 + index * 0.1 }}
                        className="flex items-center gap-2 text-xs text-muted-foreground"
                      >
                        <Clock className="w-3 h-3" />
                        <span>Filed on {claim.date}</span>
                      </motion.div>

                      {/* Actions */}
                      <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.7 + index * 0.1 }}
                        className="flex gap-2 pt-2"
                      >
                        {[
                          { icon: Eye, label: "View Proof" },
                          { icon: MessageSquare, label: "Support" },
                        ].map((action, btnIndex) => (
                          <motion.div
                            key={action.label}
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                            className="flex-1"
                          >
                            <Button
                              variant="outline"
                              size="sm"
                              className="w-full flex items-center gap-2"
                            >
                              <action.icon className="w-4 h-4" />
                              {action.label}
                            </Button>
                          </motion.div>
                        ))}
                      </motion.div>
                    </div>
                  </div>

                  {/* Animated progress bar for completed claims */}
                  {claim.status === "completed" && (
                    <motion.div
                      className="h-1 bg-green-500"
                      initial={{ width: 0 }}
                      animate={{ width: "100%" }}
                      transition={{ delay: 0.5 + index * 0.1, duration: 0.8 }}
                    />
                  )}
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* New Claim Button */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, type: "spring" }}
          className="mt-6"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          <Button className="w-full relative overflow-hidden" size="lg">
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent"
              animate={{
                x: ["-100%", "100%"],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "linear",
              }}
            />
            <FileText className="w-5 h-5 mr-2 relative z-10" />
            <span className="relative z-10">File New Claim</span>
          </Button>
        </motion.div>
      </div>
    </div>
  );
}
