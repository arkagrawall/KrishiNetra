import { projectId, publicAnonKey } from "./supabase/info"; // Assuming this path is correct

// --- Import Market Types ---
// Ensure this path points correctly to your MarketRates component file
import type { MarketRecord, ApiFilters } from "../components/MarketRates";

// ==================== BASE URLs ====================

// Base URL for Supabase functions (used by apiCall)
const SUPABASE_API_BASE_URL = `https://${projectId}.supabase.co/functions/v1/make-server-37861144`;

// Base URL for the Python/Flask Market API
// Use environment variables for flexibility
const MARKET_API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:5000";

// ==================== GENERIC API RESPONSE TYPE ====================

interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

// ==================== GENERIC SUPABASE API CALL FUNCTION ====================

// This function is specifically for calling your Supabase endpoints
async function apiCall<T>(
  endpoint: string,
  method: string = "GET",
  body?: any,
): Promise<ApiResponse<T>> {
  try {
    const options: RequestInit = {
      method,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${publicAnonKey}`, // Using Supabase anon key
      },
    };

    if (body && method !== "GET") {
      options.body = JSON.stringify(body);
    }

    const response = await fetch(
      `${SUPABASE_API_BASE_URL}${endpoint}`, // Using Supabase URL
      options,
    );
    const data = await response.json();

    if (!response.ok) {
      console.error(`Supabase API Error (${response.status}):`, data);
      return {
        success: false,
        error:
          data.error ||
          `Request failed with status ${response.status}`,
      };
    }

    // Assuming Supabase functions return data directly or nested under 'data'
    return {
      success: true,
      data: data.data || data, // Adjust if your Supabase functions have a different structure
      message: data.message,
    };
  } catch (error) {
    console.error("Supabase API Call Error:", error);
    return {
      success: false,
      error:
        error instanceof Error
          ? error.message
          : "Network error occurred calling Supabase",
    };
  }
}

// ==================== AUTH API (Uses Supabase apiCall) ====================

export const authApi = {
  signup: async (data: {
    name: string;
    phone: string;
    email?: string;
    password: string;
  }) => {
    // Specify expected return type if known, e.g., ApiResponse<{ userId: string }>
    return apiCall("/auth/signup", "POST", data);
  },

  login: async (data: { phone: string; password: string }) => {
    // Specify expected return type if known, e.g., ApiResponse<{ token: string; user: any }>
    return apiCall("/auth/login", "POST", data);
  },
};

// ==================== SENSORS API (Uses Supabase apiCall) ====================

export const sensorsApi = {
  getAll: async (userId: string) => {
    // Specify expected return type if known, e.g., ApiResponse<Sensor[]>
    return apiCall(`/sensors/${userId}`, "GET");
  },

  add: async (data: {
    userId: string;
    name: string;
    type: string;
    location: string;
  }) => {
    // Specify expected return type if known, e.g., ApiResponse<Sensor>
    return apiCall("/sensors", "POST", data);
  },

  remove: async (userId: string, sensorId: string) => {
    // Specify expected return type if known, e.g., ApiResponse<{ message: string }>
    return apiCall(`/sensors/${userId}/${sensorId}`, "DELETE");
  },
};

// ==================== VITALS API (Uses Supabase apiCall) ====================

export const vitalsApi = {
  get: async (userId: string) => {
    // Specify expected return type if known, e.g., ApiResponse<VitalsData>
    return apiCall(`/vitals/${userId}`, "GET");
  },

  update: async (userId: string, vitals: any) => { // Consider defining a type for 'vitals'
    // Specify expected return type if known, e.g., ApiResponse<VitalsData>
    return apiCall(`/vitals/${userId}`, "POST", vitals);
  },
};

// ==================== MARKET API (Uses Direct Fetch to Python Backend) ====================

export const marketApi = {
  /**
   * Fetches market prices from the Python Flask backend.
   * Returns the generic ApiResponse structure.
   */
  getPrices: async (filters: ApiFilters): Promise<ApiResponse<{ records: MarketRecord[] }>> => {
    const params = new URLSearchParams();

    if (filters.state) params.append("state", filters.state);
    if (filters.district) params.append("district", filters.district);
    if (filters.commodity) params.append("commodity", filters.commodity);
    // Add search param if your backend supports it
    // if (filters.search) params.append("search", filters.search);

    const queryString = params.toString();
    const requestUrl = `${MARKET_API_BASE_URL}/api/market-prices?${queryString}`; // Using Market URL

    console.log("Calling Market Backend API:", requestUrl);

    try {
      // Direct fetch call to the Python backend
      const response = await fetch(requestUrl);

      if (!response.ok) {
        let errorMsg = `Error: ${response.status} ${response.statusText}`;
        try {
          const errorData = await response.json();
          errorMsg = errorData.error || errorMsg;
        } catch (parseError) { /* Ignore */ }
        console.error("Market Backend API request failed:", errorMsg);
        // Return matching the generic ApiResponse structure
        return { success: false, error: errorMsg };
      }

      // Parse the JSON response from the backend
      // It should already be in { success, data: { records: [...] }, error } format
      const backendResponse = await response.json();

      // Basic validation
      if (typeof backendResponse.success !== 'boolean') {
        throw new Error("Invalid response structure from market backend: 'success' field missing or not boolean.");
      }
      // Check if data exists and records is an array when success is true
      if (backendResponse.success && (!backendResponse.data || !Array.isArray(backendResponse.data.records))) {
        console.warn("Market backend response 'success' is true, but 'data.records' is missing or not an array.");
        // Return success with empty data to align with ApiResponse<T>
        return { success: true, data: { records: [] } };
      }
      // Check if error exists when success is false
      if (!backendResponse.success && !backendResponse.error) {
        console.warn("Market backend response 'success' is false, but 'error' field is missing.");
        return { success: false, error: "Market backend indicated failure but provided no error message." };
      }


      console.log("Market Backend API Response received");
      // Explicitly cast to the expected generic type for type safety
      return backendResponse as ApiResponse<{ records: MarketRecord[] }>;

    } catch (err) {
      let errorMessage = "Network error calling market backend";
      if (err instanceof Error) {
        errorMessage = err.message;
      }
      console.error("Market API Fetch error:", errorMessage);
      // Return matching the generic ApiResponse structure
      return { success: false, error: errorMessage };
    }
  },

  // getStates function remains commented out unless implemented in Python backend
};

// ==================== ALERTS API (Uses Supabase apiCall) ====================

export const alertsApi = {
  getAll: async (userId: string) => {
    // Specify expected return type if known, e.g., ApiResponse<Alert[]>
    return apiCall(`/alerts/${userId}`, "GET");
  },

  create: async (data: {
    userId: string;
    type: string;
    severity: string;
    title: string;
    description: string;
    action: string;
  }) => {
    // Specify expected return type if known, e.g., ApiResponse<Alert>
    return apiCall("/alerts", "POST", data);
  },

  dismiss: async (userId: string, alertId: string) => {
    // Specify expected return type if known, e.g., ApiResponse<{ message: string }>
    return apiCall(`/alerts/${userId}/${alertId}`, "DELETE");
  },
};

// ==================== CLAIMS API (Uses Supabase apiCall) ====================

export const claimsApi = {
  getAll: async (userId: string) => {
    // Specify expected return type if known, e.g., ApiResponse<Claim[]>
    return apiCall(`/claims/${userId}`, "GET");
  },

  file: async (data: {
    userId: string;
    crop: string;
    event: string;
    amount: number;
    description: string;
  }) => {
    // Specify expected return type if known, e.g., ApiResponse<Claim>
    return apiCall("/claims", "POST", data);
  },

  update: async (
    userId: string,
    claimId: string,
    updates: any, // Consider defining a type for 'updates'
  ) => {
    // Specify expected return type if known, e.g., ApiResponse<Claim>
    return apiCall(
      `/claims/${userId}/${claimId}`,
      "PUT",
      updates,
    );
  },
};

// ==================== CHAT API (Uses Supabase apiCall) ====================

export const chatApi = {
  sendMessage: async (userId: string, message: string) => {
    // The generic T is specified here
    return apiCall<{ response: string }>("/chat", "POST", {
      userId,
      message,
    });
  },

  getHistory: async (userId: string) => {
    // Specify expected return type if known, e.g., ApiResponse<ChatMessage[]>
    return apiCall(`/chat/${userId}`, "GET");
  },
};

// ==================== WEATHER API (Uses Supabase apiCall) ====================

export const weatherApi = {
  getForecast: async (location: string) => {
    // Specify expected return type if known, e.g., ApiResponse<ForecastData>
    return apiCall(`/weather/${location}`, "GET");
  },
};